import React, { Component } from 'react';
import { BrowserRouter as Router, Switch, Route, Link } from 'react-router-dom';
import Home from './Home';
import Login from './Login';

class App extends Component {
   render() {
      return (
         <Router>
            <div>
               <ul>
                  <li><Link to={'/'}>Login</Link></li>
                  <li><Link to={'/Home'}>Home</Link></li>
               </ul>
               <hr />
               
               <Switch>
                  <Route exact path='/Home' component={Home} />
                  <Route exact path='/' component={Login} />
                  <Route exact path='/login' component={Login} />
				  
               </Switch>
            </div>
         </Router>
      );
   }
}
export default App;