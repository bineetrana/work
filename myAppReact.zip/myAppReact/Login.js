import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import { withRouter } from 'react-router-dom';

class Login extends Component {
	constructor(props) {
    super(props);
    this.state = {value: ''};

    this.handleChange = this.handleChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
  }

  handleChange(event) {
    this.setState({value: event.target.value});
  }

  handleSubmit(event) {
	
    alert('Login With Success: ' + this.state.value);
	this.props.history.push("/Home")
    event.preventDefault();
  }

   render() {
      return (
         <div className="loginmodal-container">
        <h1>Login to Your Account</h1><br />
        <form onSubmit={this.handleSubmit}>
          <input type="text" placeholder="Username" value={this.state.value} onChange={this.handleChange} />
          <input type="password"  placeholder="Password" />
          <input type="submit" className="login loginmodal-submit" defaultValue="Login" />
        </form>
       
      </div>
      );
   }
}
export default Login;